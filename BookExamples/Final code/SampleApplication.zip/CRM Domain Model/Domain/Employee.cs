﻿namespace CRM.Domain.Domain
{
    public sealed class Employee : Person
    {
    }
}
