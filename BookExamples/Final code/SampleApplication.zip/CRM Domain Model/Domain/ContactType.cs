namespace CRM.Domain.Domain
{
    public enum ContactType
    {
        Phone,
        Mobile,
        Private,
        Pager,
        Fax,
        Email,
        Other
    }
}