﻿namespace CRM.Domain.Domain
{
    public enum ApprovalStatus
    {
        Ordered,
        Approved,
        Denied,
        Shipped,
        Received
    }
}
