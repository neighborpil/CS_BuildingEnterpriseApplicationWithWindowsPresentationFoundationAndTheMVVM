﻿using System.Windows.Controls;

namespace CRM.MVVM.WPF.TreeViews
{
    /// <summary>
    /// Interaction logic for ProductsTree.xaml
    /// </summary>
    public partial class ProductsTree : UserControl
    {
        public ProductsTree()
        {
            InitializeComponent();
        }
    }
}