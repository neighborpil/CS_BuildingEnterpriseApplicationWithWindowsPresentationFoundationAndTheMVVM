﻿using System.Windows.Controls;

namespace CRM.MVVM.WPF.TreeViews
{
    /// <summary>
    /// Interaction logic for EmployeesTree.xaml
    /// </summary>
    public partial class EmployeesTree : UserControl
    {
        public EmployeesTree()
        {
            InitializeComponent();
        }
    }
}