﻿using System.Windows.Controls;

namespace CRM.MVVM.WPF.TreeViews
{
    /// <summary>
    /// Interaction logic for CustomersTree.xaml
    /// </summary>
    public partial class CustomersTree : UserControl
    {
        public CustomersTree()
        {
            InitializeComponent();
        }
    }
}